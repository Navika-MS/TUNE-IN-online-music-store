<html>
<head>
<title>frame1</title>
</head>
<body bgcolor="#778899">
<h2 style="font-family:verdana;color:white;text-align:center-left;">Albums available</h2>
<p>One direction</p>
<p><a href="Album 20-BTS.php" target="frame2"> BTS</a></p>
</body>
</html>