<!DOCTYPE html>
<html>
<head>
      <title> Albums-Billie Eilish</title>
</head>
<h1 align="center">Billie Eilish</h1>
<br>
<br>
<br>
<br>
<br>
<br>

<style>
table,th,td
{
 border:1px solid black;
 padding:5px;
}
table
{
 border-spacing:15px;
}
</style>

<body style=" background-color:#ffff4d  ">

 <table  style="background-color:white" align="center">
<tr>
 <th>Up Next Session</th>
 <th>Live at Third Man Records</th>
 <th>When we all fall asleep Where do we go</th>
 
</tr>
 <tr>
 <td><a href="  "> 
        <img alt="up next session" src="Billie-1.png"  width="250" height="250"></a>  </td>
 <td><a href="  "> 
        <img alt="live at third man record" src="Billie 2- live at the third man records.png"  width="250" height="250"></a></td>

 <td ><a href=" ">
     <img alt="wwafawdwg" src="Billie 3-when we all fall sleep where do we go.png"  width="250" height="250"></a>  </td>

 
</tr>
</body>
</table>
</html>