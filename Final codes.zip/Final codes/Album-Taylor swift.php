<!DOCTYPE html>
<html>
<head>
      <title> Albums-Taylor Swift</title>
</head>
<h1 align="center">TAYLOR SWIFT</h1>
<br>
<br>
<br>
<br>
<br>
<br>

<style>
table,th,td
{
 border:1px solid black;
 padding:5px;
}
table
{
 border-spacing:15px;
}
</style>

<body style=" background-color:#ffff4d  ">

 <table  style="background-color:white" align="center">
<tr>
 <th>Fearless</th>
 <th>Red</th>
 <th>1989</th>
 <th>Reputation</th>
 <th>Folklore</th>
</tr>
 <tr>
 <td><a href=" Taylor-Fearless.php "> 
        <img alt="Fearless" src="Taylor 1-Fearless.png"  width="250" height="250"></a>  </td>
 <td><a href="  "> 
        <img alt="Red" src="Taylor 2-Red.png  "  width="250" height="250"></a></td>

 <td ><a href=" ">
     <img alt="1989" src="Taylor 3 -1989.png"  width="250" height="250"></a>  </td>

 <td><a href="  "> 
        <img alt="Reputation" src=" Taylor 4 -Reputation.png"  width="250" height="250"></a>  </td>
 <td><a href="  "> 
        <img alt="Folklore" src=" Taylor 5 -Folklore.png "  width="250" height="250"></a></td>
</tr>
</body>
</table>
</html>