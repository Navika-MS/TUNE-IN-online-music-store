<html>
<h1> Electronics display</h1>
<body bgcolor="#FA8072">



</body>
</html>