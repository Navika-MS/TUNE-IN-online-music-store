<!DOCTYPE html>
<html>
 <head>
 <title> MERCHANDISE </title>
 </head>
<h1 align="center">Merchandise<h1>
<body style="background-color:#9C5ADE ;">
<table >
<tr>
<td><img alt="1" src="merch 1.png" width="300px" height="300px"> </td>
<td> <img alt="2" src="merch 2.png" width="300px" height="300px"></td>
<td> <img alt="3" src="merch 3.png" width="300px" height="300px"></td>
</tr>
<tr>
<td> <img alt="4" src="merch 4.png" width="300px" height="300px"></td>
<td><img alt="5" src="merch 5.png" width="300px" height="300px"> </td>
<td> <img alt="6" src="merch 6.png" width="300px" height="300px"></td>
</tr>


</table>


<h4><a href="Homepage.php"> HOME</a></h4>
</body>
</html>