<!DOCTYPE html>
<html>
 <head>
 <title> ALBUMS </title>
 </head>
<h1 align="center">Albums<h1>
<hr>
ARTISTS

<style>
table,th,td
{
 border:1px solid black;
 padding:5px;
}
table
{
 border-spacing:15px;
}
</style>

<body bgcolor="#FADBD8 ";>

 <table align="center">
<tr>
  <th>ONE DIRECTION</th>
  <th>TAYLOR SWIFT</th>
  <th>BILLIE EILISH</th>
  
</tr>

<tr>  
   <td><a href="Album-One direction.php  "> 
        <img alt="ONE DIRECTION" src="One direction cover pic.png  "  width="300" height="300"></a>  </td>
   <td> <a href="Album-Taylor swift.php "> 
        <img alt="TAYLOR SWIFT" src="Taylor cover pic.png  "  width="250" height="300"></a> </td>
   <td><a href="Album-Bilie eilish.php"> 
        <img alt="BILLIE" src="Billie cover pic.png   "  width="250" height="300"></a> </td>
</tr>
<tr>
   <th>BTS</th>
  <th>SHAWN MENDES</th>
  <th> JUSTIN BIEBER</th>
</tr>
<tr>
   <td><a href="Album -BTS.php">
       <img alt="BTS" src="BTS cover pic.png" width="300" height="300"> </a></td>
   <td> <a href="Album-shawn mendes.php  "> 
        <img alt="SHAWN MENDES" src="Shwan mendes cover pic.png  "  width="250" height="300"></a>  </td>
   <td>  <a href=" Album-Justin.php  "> 
        <img alt="JUSTIN BIEBER" src="Justin cover pic.png  "  width="250" height="300"></a>  </td>
   
</tr>
</table>






</ul>
<h5><a href="Homepage.php"> Home</a></h5>
</body>
</html>