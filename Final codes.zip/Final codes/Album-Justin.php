<!DOCTYPE html>
<html>
<head>
      <title> Albums-Justin Bieber</title>
</head>
<h1 align="center">JUSTIN BIEBER</h1>
<br>
<br>
<br>
<br>
<br>
<br>

<style>
table,th,td
{
 border:1px solid black;
 padding:5px;
}
table
{
 border-spacing:15px;
}
</style>

<body style=" background-color:#EC7063  ">

 <table  style="background-color:white" align="center">
<tr>
  <th>My World 2.0</th>
  <th>Under The Mistletoe </th>
  <th> Believe</th>
  <th>Purpose</th>
  <th>Changes</th>
  <th>Justice </th>
</tr>
<tr>
 <td><a href="  "> 
        <img alt="My World 2.0" src="Justin 1-my world 2.0.png"  width="250" height="250"></a>  </td>
 <td><a href="  "> 
        <img alt="Under The Mistletoe" src=" Justin 2-under the mistletoe.png"  width="250" height="250"></a></td>
 <td><a href="  "> 
        <img alt="Believe" src=" Justin 3-believe.png "  width="250" height="250"></a></td>
 <td><a href="  "> 
        <img alt="Purpose" src=" Justin 4-purpose.png"  width="250" height="250"></a></td>
 <td><a href="  "> 
        <img alt="Changes" src="Justin 5-changes.png "  width="250" height="250"></a></td>
 <td><a href="  "> 
        <img alt="Justice" src=" Justin 6-justice.png "  width="250" height="250"></a></td>
</table>
</body>
</html>