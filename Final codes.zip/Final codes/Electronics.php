
<html>
<head>
<title>ELECTRONICS</title>

</head>
<frameset rows=20%,*>
  <frame src="topframe.php">
   <frameset cols=30%,*%>
      <frame src="electronic frame 1.php"  name="one">
      <frame src="electronic2.php"  name="two">
</frameset>

</frameset>

</html>