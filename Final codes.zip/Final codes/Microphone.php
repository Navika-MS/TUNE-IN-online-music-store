<html>
<head>
<title>Microphone</title>
</head>
<body style="background-color:#ABEBC6 ;">
<table  border="3" align="center">
<tr >
<th> Stand Mic</th>
<th>Karoke Mic</th>
</tr>

<tr>
<td><a href=" Mic 1.php " target="_blank">
        <img alt=" Mic 1"  src="Mic 1.1.png" width="300" height="300"></a> </td>
<td> <a href="  "> 
        <img alt="Mic 2"   src="Mic 2.2.png" width="300" height="300"></a></td>
</tr>
<tr>
<th> Table Mic</th>
<th> Coloured Mic</th>
</tr>
<tr>
<td><a href="  "> 
        <img alt="Mic 3" src="Mic 3.3.png"  width="300" height="300"></a> </td>
<td><a href="  "> 
        <img alt="Mic 4" src="Mic 4.png"  width="280" height="280"></a> </td>
</tr>
</table>
<button type="submit"><a href="Homepage.php">Back To Home</a>
</body>
</html>