<html>
<head>
<title>TUNE IN</title>
<style>
.button {
  display: inline-block;
  padding: 15px 25px;
  font-size: 24px;
  cursor: pointer;
  text-align: center;
  text-decoration: none;
  outline: none;
  color: #FDFEFE;
  background-color: #4CAF50;
  border: none;
  border-radius: 15px;
  box-shadow: 0 9px #999;
}

.button:hover {background-color: #FDFEFE}

.button:active {
  background-color: #FDFEFE;
  box-shadow: #FDFEFE;
  transform: translateY(4px);
}
</style>
</head>
<body align="center" bgcolor="#f26724""><br><br><br>
<h1><b><button class="button"> WELCOME TO TUNE IN</b></button></h1><br><br>
<h2><button class="button"><a href="1.php">SIGN UP</a></h2><br><br></button>
<h2><button class="button"><a href="3.php">LOGIN IN</a></h2><br><br></button>
</body>
</html>