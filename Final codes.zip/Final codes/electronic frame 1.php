<!DOCTYPE html>
<html>
<head>
<title> electronic frame1</title>
</head>
<body bgcolor="#FA8072">
<h2 style="font-family:verdana;color:white;text-align:center-left;">Electronics</h2>
<ul>
<h1><li><a href="Microphone.php" target="two" > Microphones</a></li>
  <li>Speakers</li>
  <li>Headsets</li>
  <li>Accessories</li>
</ul>  </h1>

</body>
</html>