<html>
<head>
<title>BTS ALBUM</title>
</head>
<frameset rows=20%,*>
  <frame src="top frame.html">
   <frameset cols=15%,*%>
      <frame src="frame1.html"  name="frame1">
      <frame src="frame2.html"  name="frame2">
</frameset>
</frameset>
</html>