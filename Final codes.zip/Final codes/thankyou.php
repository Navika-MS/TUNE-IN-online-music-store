<html>
<body background="shape.jpg  ";>
<h1 align="center">THANK YOU<h1>
</body>
</html>