<!DOCTYPE html>
<html>
 <head>
 <title> ABOUT US </title>
 </head>
<body bgcolor="#22FCEA ";>
<h1 style="text-align:center;">  Tune In </h1>
<h3 style="text-align:center;"> Connect to music through different means !</h3>
<hr>
<h2 style="text-align:center;"> ABOUT US</h2>

<p style="font-size:150%;" style= "text-align:center;" >

TUNE IN provides fans one place to discover and buy music related electonics,albums and merch from all their favorite bands. A place that is a joy to shop, magically matches you with merch from bands you love and provides an unrivaled shopping, purchase and return experience so you can buy with confidence.</p>

<p style="font-size:150%;">
Our team brings you the best quality electronic from various brands around the world.
Each and every product is untouched and supplied directly from the production centers.
we assure the quality the products.Albums from artists around the world in one place.No need to search for various pages to buy your favorite albums.</p>

<p style="font-size:150%;">
Not only albums we also provide merch of your favorites around tha world at the finest quality
Our team of engineers, hackers, designers, lawyers (this is the music industry after all!) and merchandisers work hard every day with merch companies, artists, independent labels and distributors to create a company that not only helps fans but supports artists and the teams behind them.</p>

<p style="font-size:150%;>
I hope you have a great experience at Merchbar, let me know if there’s anything we can do to make it better.</p>

<button type="submit"> <a href="Homepage.php">Back To Home</a>
</body>




</html>