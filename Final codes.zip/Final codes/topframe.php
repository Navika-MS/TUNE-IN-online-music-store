<html>
<head>
<title>Albums</title>
</head>
<body bgcolor="#FA8072">
<header>ALBUMS</header>

</body>
</html>