<html>
    <head>
        <style>
            body {
            background: url(cit1.jpg);
            background-size: 100%;
            background-repeat: no-repeat;
            }
        </style>
    </head>
    <body>
    `    <?php
            // Connect to the database
            $host="localhost";
            $user="root";
            $password="";
			
            $connect=mysqli_connect($host,$user,$password,"navika");
            
            // Get the submitted form control data values 
            $username=$_GET['username'];
           
            $pass=$_GET['pass'];
             $query="SELECT*FROM signup where username='$username'and password='$pass'";
             $result=mysqli_query($connect,$query);
             $count=mysqli_num_rows($result);
             if($count>0)
	            header("Location:Homepage.php");
             else
	         print("Login unsuccessful");
            mysqli_close($connect)
            ?>
    </body>
</html>