<!DOCTYPE html>
<html>
 <head>
 <link rel="styleslide" href="C:\Users\Navika M S\Documents\1.Wepage desiginig\style.css">
<style>


.button {
  display: inline-block;
  padding: 10px 15px;
  font-size: 24px;
  cursor: pointer;
  text-align: center;
  text-decoration: none;
  outline: none;
  color: #FDFEFE;
  background-color: white;
  border: none;
  border-radius: 15px;
}

.button:hover {background-color: #e6a800}

.button:active {
  background-color: #FDFEFE;
 
  transform: translateY(4px);
}
</style>
 <title > TUNE IN </title>
 </head>

<body background="Homepage background.jpg">

<h1 align="center"><b> TUNE IN<b><h1>
<hr   width=100% >


<h5 >
<button class="button"><a href="About us.php">About us</a></button>&nbsp&nbsp&nbsp&nbsp
 

 
<button class="button"><a href="Electronics.php"> Electronics</a></button>&nbsp
 &nbsp
 &nbsp
 &nbsp
 
<button class="button"><a href="Albums.php"> Albums</a></button>&nbsp
 &nbsp
 &nbsp
 &nbsp
 
<button class="button"><a href="Merchandise.php" > Merch</a></button>&nbsp
 &nbsp
 &nbsp
 &nbsp
 
<button class="button"><a href="feedback.php">Feedback</a></button>

&nbsp
 &nbsp
 &nbsp

<button class="button"><a href="Admin panel.php">Admin</a></button></h5>
<hr width=100% colour="green">

 </body>
</html>
