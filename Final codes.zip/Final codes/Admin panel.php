<html>
<head>

<title>
Admin panel
</title>
<style>
.button {
  display: inline-block;
  padding: 10px 15px;
  font-size: 24px;
  cursor: pointer;
  text-align: center;
  text-decoration: none;
  outline: none;
  color: #FDFEFE;
  background-color: white;
  border: none;
  border-radius: 15px;
}

.button:hover {background-color: #e6a800}

.button:active {
  background-color: #FDFEFE;
 
  transform: translateY(4px);
}
</style>
<body align="center" bgcolor="yellow";>
<br><br>
<H1 align ="center"> Welcome To Admin Panel!</h1>
<br>
<br>
<br>
<br>
<br>

<button class="button"> <a href="feedbackdisplay.php">FEEDBACK DISPLAY</a></button>
<br><br><br>
<button class="button"><a href="signupdisplay.php">SIGNUP DISPLAY</a></button>


 
</body>
</html>