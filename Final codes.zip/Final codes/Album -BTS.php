<!DOCTYPE html>
<html>
<head>
      <title> Albums-BTS</title>
</head>
<h1 align="center">BANGTAN SONYEODAN</h1>

<style>
table,th,td
{
 border:1px solid black;
 padding:5px;
}
table
{
 border-spacing:15px;
}
</style>

<body style=" background-color:#D7BDE2 ">

 <table  style="background-color:white" align="center">
<tr>
 <th>Skool Luv Affair</th>
 <th>Dark & Wild</th>
 <th>Young Forever</th>
 <th>Wings</th>
</tr>
<tr>
 <td><a href="  "> 
        <img alt="Skool luv affair" src="BTS 1-skool luv affair.png "  width="250" height="250"></a>  </td>
 <td><a href="  "> 
        <img alt="Dark and wild" src="BTS 2-dark and wild.png  "  width="250" height="250"></a></td>
 <td> <a href=" "> 
        <img alt="Young forever" src=" BTS 3-young forever.png  "  width="250" height="250"></a> </td>
 <td><a href="  "> 
        <img alt="Wings" src=" BTS 4-wings.png"  width="250" height="250"></a></td>
</tr>

<tr>
 <th>Love Yourself</th>
 <th>Map of the soul 7</th>
 <th> Map of the soul'Persona'</th>
  <th>BE</th> 
</tr>
<tr>
 
 <td><a href=" "> 
        <img alt="Love yourself" src="BTS 5-loveyourself.png  "  width="250" height="250"></a></td>
 
 <td><a href="   "> 
        <img alt="Map of the soul 7" src=" BTS 6-map of the soul.png  "  width="250" height="250"></a></td>
 <td><a href" ">
        <img alt="Map of the soul 'persona' " src=" BTS 6.2-map of the soul persona.png" width="250" height="250"></a></td> 
 <td><a href="   "> 
        <img alt="BE" src=" BTS 7-be.png "  width="250" height="250"></a></td> 
</tr>

</table>
</body>
</html>
