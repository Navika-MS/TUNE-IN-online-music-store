<?php 
$con=mysqli_connect("localhost","root","","navika"); 
if(!$con) { die(" Connection Error "); } 
?>