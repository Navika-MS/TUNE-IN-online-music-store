<html>
<head>
<title> Mic 1</title>
</html>
<body bgcolor="#CCCCFF";>



<table border="2px"; align="center" width="600px" height=350px">
<tr >

<td>
<img alt="mic 1" src="Mic 1.1.png" width="350px" height="350px">
</td>
<td>
Model :Maono AU-PM421 Condenser USB Microphone, Professional Studio Recording Mic with 1-Touch Mute and Mic Gain Knob for PC, Singing, Podcast, Gaming, YouTube<br>
<br>
<b>Price : ₹ 5,199.00</b><br>
<button class="button"><a href="5.php" target="_blank">BUY NOW</a></button>

</td>


</tr>
</table>

<p >* Professinal Sound Chipset 192KHZ/24BIT: This USB condenser microphone is designed with the professional sound chipset and 16mm electret condenser transducer</p>
<p>* Quickly Touch Mute And Mic Gain Knob: Touch-key mute/unmute your microphone, and the built-in LED Indicator lights to tell you the working status (Green Light: Working, Red Light: Mute)</p>
<p >* Cardioid Mode: Cardioid mode captures sound sources that are directly in front of the microphone. It delivers a rich, full-bodied sound</p>

<p >* Premium Microphone Arm Set: High-quality metal arms stand and shock mount to isolate USB mic from noise. Pop filter and windscreen cap can lower wind and Saliva interference</p>
<p >* Plug & Play: The microphone has a USB data port, easy to connect with computers. Only select USB mic as default input in your software settings. 2.5m double shielding USB cable reduces interference</p>
<p >
* Package List: 1x condenser microphone, 1x adjustable sturdy arm, 1x desk mount clamp, 1x metal shock mount, 1x pop filter, 1x windscreen cap, 1x USB cable and 1x manual instruction</p>

<button class="button"><a href="Homepage.php" target="_blank">HOME</a></button>
<button class="button"><a href="ELECTRONICS.php" target="_blank">BACK</a></button>

</body>
</html>