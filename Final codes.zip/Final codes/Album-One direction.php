<!DOCTYPE html>
<html>
<head>
      <title> Albums-One Direction</title>
</head>
<h1 align="center">ONE DIRECTION</h1>
<br>
<br>
<br>
<br>
<br>
<br>

<style>
table,th,td
{
 border:1px solid black;
 padding:5px;
}
table
{
 border-spacing:15px;
}
</style>

<body style=" background-color:#EC7063  ">

 <table  style="background-color:white" align="center">
<tr>
 <th>Up All Night</th>
 <th> Take Me Home</th>
 <th>Midnight Memories</th>
 <th>Four</th>
  <th>Made In The A.M</th>
</tr>
<tr>
 <td><a href="One direction-up all night.php  "> 
        <img alt="Up All Night" src="One direction 1-up all night.png "  width="250" height="250"></a>  </td>
 <td><a href="  "> 
        <img alt="Take Me Home" src=" One direction 2-take me home.png "  width="250" height="250"></a></td>

 <td ><a href=" ">
     <img alt="Midnight Memories" src="One direction 3-midnight memories.png "  width="250" height="250"></a>  </td>

 <td><a href="  "> 
        <img alt="Four" src=" One direction 4- four.png"  width="250" height="250"></a>  </td>
 <td><a href="  "> 
        <img alt="Made In The A.M" src="One direction 5-made in the a.m.png  "  width="250" height="250"></a></td>
</tr>
</body>
</table>
</html>