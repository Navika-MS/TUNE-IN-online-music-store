<html>
<head>
<title>One Direction-Up all night</title>
</head>
<body style="background-color:#F5B7B1 ";>
<img alt="1d up all night" src="One direction -up all night songs.png " width="1600" height="500">


<h2>
Up All Night is the debut studio album by English-Irish boy band One Direction, released by Syco Records<br> in November 2011 in Ireland and the United Kingdom, followed by a<br> worldwide release during 2012.
<br>
Artist      : One Direction<br>
Release date: 18 November 2011<br>
Awards      : People's Choice Award for Favorite Album, BBC Radio 1 Teen Award for Best British Album<br>
Producers   : Matt Squire, Savan Kotecha, Ash Howes, BeatGeek, MORE<br>
Genres      : Pop music, Pop rock, Teen pop, Dance-pop, Soft rock, Indie pop, Power pop<br>
</h2>
</body
</html>