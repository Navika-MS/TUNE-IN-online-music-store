<!DOCTYPE html>
<html>
<head>
      <title> Albums-Shawn Mendes</title>
</head>
<h1 align="center">Shawn Mendes</h1>
<br>
<br>
<br>
<br>
<br>
<br>

<style>
table,th,td
{
 border:1px solid black;
 padding:5px;
}
table
{
 border-spacing:15px;
}
</style>

<body style=" background-color:#ffff4d  ">

 <table  style="background-color:white" align="center">
<tr>
 <th>Handwritten</th>
 <th>Illuminate</th>
 <th>Shawn Mendes</th>
 <th>Wonder</th>
 
</tr>
 <tr>
 <td><a href="  "> 
        <img alt="Handwritten" src="Shawn 1-handwritten.png"  width="250" height="250"></a>  </td>
 <td><a href="  "> 
        <img alt="Illuminate" src="Shawn 2-illuminate.png "  width="250" height="250"></a></td>

 <td ><a href=" ">
     <img alt="Shawn Mendes" src="Shawn 3-shawn mendes.png"  width="250" height="250"></a>  </td>

 <td><a href="  "> 
        <img alt="Wonder" src=" Shawn 4-wonder.png"  width="250" height="250"></a>  </td>

</tr>
</body>
</table>
</html>