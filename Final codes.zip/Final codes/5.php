<html>
    <head>
        <title>Billing</title>
       
        <form  name="bill" action="6.php">
    </head>

<body bgcolor="powderblue">

<center>
<br>
<br>
        <H1>Name:Address:Contact</H1><input type="text"  name="a" required ></input><br><br><br>
        <H1>Cardnumber:</H1><input type="text"  name="b" required ></input><br><br><br>
        <h1>cvv:</h1><input type="text" name="c" required></input><br><br><br>
        <input type="submit" value="SUBMIT" onclick="C:\xampp\htdocs\Navikaproject\Final codes\pdf generation\form.php">
 <button type="button"><a href="Mic 1.php"> CANCEL</a></button>
        </center>

    </form>
    </body>
</html>