<html>
<head>
<title> ALBUM</title>
</head>
<frameset rows=20%,*>
  <frame src="topframe.html">
   <frameset cols=50%,50%>
      <frame src="frame1.html"  name="frame1">
      <frame src="frame2.html"  name="frame2">
</frameset>
</frameset>
</html>