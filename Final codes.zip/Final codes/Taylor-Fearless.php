<html>
<head> 
<title>Taylor-Fearless</title>
</head>
<body  style="background-color:#EAFAF1 ;">
<img alt="Fearless" src="Taylor fearless songs.png" width="900" height="200">

<h2 align="center"> Album History</h2>
<h3>
Released   :	November 11, 2008<br>
Recorded   :    2007–2008<br>
Genre	   :    Country pop<br>
Length	   :     53:41<br>
Label      :	Big Machine</h3><br>
<h2>Producer	</h2>
Nathan ChapmanTaylor Swift<br>
<h2>Singles from Fearless</h2><br>
<h3>"Love Story" 
Released: September 12, 2008<br>
"White Horse"
Released: December 7, 2008<br>
"You Belong with Me"
Released: April 18, 2009<br>
"Fifteen"
Released: August 30, 2009<br>
"Fearless"
Released: January 3, 2010</h3>

</body>
</html>