<html>
<head>
<title>pdf gen</title>
</head>

<body>
<br><br><br>

<form action="pdf.php" method="POST">
<table border="0" bgcolor="pink" align="center" cellspacing="20">

<tr>
<td>Product</td>
<td><input type="text" placeholder="Product Name" name="rollno"></td>
</tr>

<tr>
<td>Card Holder Name</td>
<td><input type="text" placeholder="Name" name="Name"></td>
</tr>

<tr>
<td>Cvv</td>
<td><input type="text" placeholder="Cvv" name="cvv"></td>
</tr>

<tr>
<td>email address</td>
<td><input type="text" placeholder="email" name="email"></td>
</tr>

<tr>
<td colspan="2" align="center"><input type="submit" id="button" name="submit"></td>
</tr>
</form>
</table>
</body>
</html>